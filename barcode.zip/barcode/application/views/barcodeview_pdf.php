<?php
$this->load->library('mpdf');
$mpdf = new mPDF('utf-8', array(160,211));
$mpdf->SetMargins(0, 0, 0,0);
// $mpdf->AddPageByArray([
//          'margin-left' => '.1mm',
//          'margin-right' => '.1mm',
//          'margin-top' => '.4mm',
//          'margin-bottom' => '0mm',
//          ]);
$html1 ='
<style type="text/css">
    .pagediv{
    width: 160mm;
    height: 210mm;
}
.maindiv{
    float: left;
    text-align: center;
    width:38mm!important;
    hight:20mm!important;
    padding-top: 1.9mm!important;
    padding-left: 1.5mm!important;
   /* border:.3px solid black;*/
  /*  padding-left: 3.2px!important;
    padding-right: 3px!important;
    padding-bottom: 2px!important;
    padding-top: 2.2px!important;*/
}
img{
    width:25mm!important;
    hight:17mm!important;
    padding: 3.5mm!important;
    padding-top: 3.5mm;
    text-align: center!important;
}
 @media print{
    @page{
        margin: 0mm;
        margin-header: 5mm; 
        margin-footer: 5mm; 
    }
 }
</style>
<div class="pagediv" id="pagediv">';
$count = 0;
 foreach($survey as $key=>$value){
$count++;
if($count > 16){
$html1.= '<div class="maindiv">
   <img style="padding-top:3.8mm!important" src="'. base_url('generate/'.$value->climate_st_id).'"> 
</div>';
}else{
  $html1.= '<div class="maindiv">
   <img style="padding-top:3.5mm!important" src="'. base_url('generate/'.$value->climate_st_id).'"> 
</div>';  
 }
}

$html2 = '</div>';
$html =  $html1." ".$html2;
$mpdf->WriteHTML($html);
$mpdf->Output('barcode.pdf', 'I');
exit;
?>