<html>
    <head>
      <meta http-equiv="content-type" content="text/html; charset=utf-8" />

<style>



body {
  font-family: "Droid Sans","Helvetica Neue",Helvetica,Arial,SolaimanLipi,sans-serif;
}
.pagediv{
    width: 160mm;
    height: 211mm;
}
.maindiv{
    float: left;
    text-align: center;
    width:39mm!important;
    hight:24mm!important;
    padding-top: 5.5px!important;
    padding-left: 3.5px!important;
  /*  padding-left: 3.2px!important;
    padding-right: 3px!important;
    padding-bottom: 2px!important;
    padding-top: 2.2px!important;*/
}
img{
    width:25mm!important;
    hight:17mm!important;
    padding: 3.5mm!important;
    padding-top: 3.8mm;
    text-align: center!important;
}
.btn {
  border: none;
  color: white;
  padding: 14px 28px;
  font-size: 16px;
  cursor: pointer;
}

.success {background-color: #04AA6D;} /* Green */
.success:hover {background-color: #46a049;}
 @media print{
    .pagediv{
    width: 604px!important;
    height: 750px!important;
}
.maindiv{
    float: left!important;
    text-align: center!important;
    width:145px!important;
    hight:72px!important;
    padding-bottom: 25px!important;
}
img{
    width:144px!important;
    hight:71px!important;
}
#prtnBtn{
    display: none;
}
}
    </style>

        
    </head>

    <body>
<div style="padding-top:10px;margin-left: 160px;">
<a class="btn success" id="prtnBtn" target="_blank" href="<?php echo base_url('platform/barcodepdf'); ?>">Export To Pdf</a>
</div>
<br>
  <?php $aarr = array(1001,1002,1003,1004,1005,1006,1007,1008,1009,1010,1011,1012,1013,1014,1015,1016,1017,1018,1019,1020,1021,1022,1023,1024,1025,1026,1027,1028,1029,1030,1031,1032,1033,1034,1035,1036,1037,1038,1039,1040); ?> 
<div class="pagediv" id="pagediv">
    <?php 
     foreach($survey as $key=>$value){ ?>
<div class="maindiv">
   <img src="<?php echo base_url('generate/'.$value->climate_st_id); ?>"> 
</div>
<?php } ?>

</div>
<br>

<script type="text/javascript">
   function printDiv() {
    var divToPrint = document.getElementById('pagediv');
    var newWin = window.open('', 'Print-Window');
    newWin.document.open();
    newWin.document.write('<html><body onload="window.print()">' + divToPrint.innerHTML + '</body></html>');
    newWin.document.close();
    setTimeout(function () {
        newWin.close();
    }, 10);
}
</script>
</body>
</html>
