<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Platform extends CI_Controller 
{

	function index($string='')
	{
		$this->load->library('mpdf');
		$this->load->library('zend');
		$this->zend->load('Zend/Barcode');
		// $mpdf = new mPDF('en', 'A4', 5);
		// $mpdf->AddPage('P');
        // $html = $this->load->view('barcodeview',$data,true);
        // $mpdf->WriteHTML($html);
       // $mpdf->Output('bar.pdf','I');
		// $string = array('name1'=> 1001,'name2'=> 1002);
		// $string1 = array('name1'=> 1003,'name2'=> 1002);
		//print_r($string);exit();
		
			Zend_Barcode::render('code128', 'image', array('text' => $string, 'barThickWidth' => 7, 'barHeight' => 30), array('imageType' => 'png'));
		
		// foreach($string1 as $key=>$value){
		// 	Zend_Barcode::render('code128', 'image', array('text' => $value, 'barThickWidth' => 5, 'barHeight' => 30), array('imageType' => 'png'));
		// }
		//$data=Zend_Barcode::render('code128', 'image', array('text' => $string, 'barThickWidth' => 5, 'barHeight' => 30), array('imageType' => 'png'));
		//print_r($data);exit(); 
		//$this->load->view('barcodeview',$data,true);
	}

	function viewpage(){
		$this->load->database();
		$this->load->model('survey_mdl');
		$data['survey'] = $this->survey_mdl->get_barcodeList();
	 	// $this->load->library('mpdf');
	 	//  $mpdf = new mPDF('utf-8', array(160,198));
	 	//  $mpdf->AddPage('P');
        //   $html = $this->load->view('barcodeview_pdf',$data,true);
        //   $mpdf->WriteHTML($html);
        //  $mpdf->Output('barcode.pdf','I');
				//print_r($data);exit();
		$this->load->view('barcodeview',$data);
	}

	function barcodepdf(){
		$this->load->database();
		$this->load->model('survey_mdl');
		$data['survey'] = $this->survey_mdl->get_barcodeList();

		 $this->load->view('barcodeview_pdf',$data);
		 // $this->load->library('mpdf');
		 // $mpdf = new mPDF('utf-8', array(160,211));
		 // $mpdf->AddPage('P');
		 // $mpdf->WriteHTML($html);
		 // $mpdf->Output('barcode.pdf','I');
	 	//$this->load->library('mpdf');
	 	// $mpdf = new mPDF('utf-8', array(160,211));
	 	// $mpdf->AddPageByArray([
	    // 'margin-left' => '.1mm',
	    // 'margin-right' => '.1mm',
	    // 'margin-top' => '0mm',
	    // 'margin-bottom' => '0mm',
		// ]);
	 	// $mpdf->AddPage('P');
        //$html = $this->load->view('barcodeview_pdf',$data,true);
        
        // $mpdf->WriteHTML($html);
        // $mpdf->Output('barcode.pdf','I');
	}
	
}


/* End of file Platform.php */
/* Location: ./application/controllers/Platform.php */