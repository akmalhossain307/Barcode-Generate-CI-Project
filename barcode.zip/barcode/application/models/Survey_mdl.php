<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Survey_mdl extends CI_Model
{

	function get_barcodeList() 
	{ 
		//$this->load->database();
		$query = $this->db->query("SELECT climate_st_id FROM climate_student LIMIT 0,40");
		$data = $query->result();
		return $data;
	}
}