<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-04 06:10:31 --> Severity: Parsing Error --> syntax error, unexpected '<', expecting ']' D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 5
ERROR - 2023-09-04 06:10:43 --> Severity: Parsing Error --> syntax error, unexpected '<' D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 4
ERROR - 2023-09-04 06:30:57 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 3
ERROR - 2023-09-04 10:16:23 --> Severity: Error --> Call to undefined method mPDF::SetFooterMargin() D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 5
