<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-03 04:01:24 --> 404 Page Not Found: Generate/index
ERROR - 2023-09-03 10:25:46 --> 404 Page Not Found: Barcodepdf/index
ERROR - 2023-09-03 10:30:05 --> Severity: Error --> Class 'Mpdf\Mpdf' not found D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 2
ERROR - 2023-09-03 10:38:36 --> Severity: Error --> Unsupported operand types D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 3698
ERROR - 2023-09-03 10:38:45 --> Severity: Error --> Unsupported operand types D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 3698
ERROR - 2023-09-03 10:39:35 --> Severity: Parsing Error --> syntax error, unexpected 'generate' (T_STRING) D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 53
ERROR - 2023-09-03 10:39:58 --> Severity: Parsing Error --> syntax error, unexpected 'generate' (T_STRING) D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 53
ERROR - 2023-09-03 10:43:21 --> Severity: Notice --> Array to string conversion D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 50
ERROR - 2023-09-03 10:43:21 --> Severity: Notice --> Undefined variable: key D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 50
ERROR - 2023-09-03 10:43:21 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 52
ERROR - 2023-09-03 10:43:21 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 52
ERROR - 2023-09-03 10:43:21 --> Severity: Notice --> Trying to get property of non-object D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 52
ERROR - 2023-09-03 10:43:26 --> Severity: Notice --> Array to string conversion D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 50
ERROR - 2023-09-03 10:43:26 --> Severity: Notice --> Undefined variable: key D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 50
ERROR - 2023-09-03 10:43:26 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 52
ERROR - 2023-09-03 10:43:26 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 52
ERROR - 2023-09-03 10:43:26 --> Severity: Notice --> Trying to get property of non-object D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 52
ERROR - 2023-09-03 10:43:32 --> Severity: Notice --> Array to string conversion D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 50
ERROR - 2023-09-03 10:43:32 --> Severity: Notice --> Undefined variable: key D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 50
ERROR - 2023-09-03 10:43:32 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 52
ERROR - 2023-09-03 10:43:32 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 52
ERROR - 2023-09-03 10:43:32 --> Severity: Notice --> Trying to get property of non-object D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 52
ERROR - 2023-09-03 10:44:03 --> Severity: Parsing Error --> syntax error, unexpected '?' D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 52
ERROR - 2023-09-03 10:44:59 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 52
ERROR - 2023-09-03 10:44:59 --> Severity: Notice --> Trying to get property of non-object D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 52
ERROR - 2023-09-03 10:45:00 --> 404 Page Not Found: Generate/index
ERROR - 2023-09-03 10:45:00 --> 404 Page Not Found: Generate/index
ERROR - 2023-09-03 10:45:00 --> 404 Page Not Found: Generate/index
ERROR - 2023-09-03 10:51:49 --> Severity: Warning --> include(../vendor/autoload.php): failed to open stream: No such file or directory D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 2
ERROR - 2023-09-03 10:51:49 --> Severity: Warning --> include(): Failed opening '../vendor/autoload.php' for inclusion (include_path='.;C:\php\pear') D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 2
ERROR - 2023-09-03 10:51:49 --> Severity: Error --> Class 'Mpdf\Mpdf' not found D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 3
ERROR - 2023-09-03 10:53:11 --> Severity: Error --> Class 'Mpdf\Mpdf' not found D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 3
ERROR - 2023-09-03 10:54:42 --> Severity: Parsing Error --> syntax error, unexpected 'generate' (T_STRING) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 8
ERROR - 2023-09-03 10:56:34 --> Severity: Parsing Error --> syntax error, unexpected '.' D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 8
ERROR - 2023-09-03 10:56:44 --> Severity: Parsing Error --> syntax error, unexpected 'generate' (T_STRING) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 8
ERROR - 2023-09-03 10:56:45 --> Severity: Parsing Error --> syntax error, unexpected 'generate' (T_STRING) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 8
ERROR - 2023-09-03 10:56:45 --> Severity: Parsing Error --> syntax error, unexpected 'generate' (T_STRING) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 8
ERROR - 2023-09-03 11:09:45 --> Severity: Parsing Error --> syntax error, unexpected 'generate' (T_STRING) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 8
ERROR - 2023-09-03 11:09:46 --> Severity: Parsing Error --> syntax error, unexpected 'generate' (T_STRING) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 8
ERROR - 2023-09-03 11:09:47 --> Severity: Parsing Error --> syntax error, unexpected 'generate' (T_STRING) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 8
ERROR - 2023-09-03 11:09:47 --> Severity: Parsing Error --> syntax error, unexpected 'generate' (T_STRING) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 8
ERROR - 2023-09-03 11:09:47 --> Severity: Parsing Error --> syntax error, unexpected 'generate' (T_STRING) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 8
ERROR - 2023-09-03 11:11:26 --> Severity: Parsing Error --> syntax error, unexpected 'foreach' (T_FOREACH) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 6
ERROR - 2023-09-03 11:12:17 --> Severity: Parsing Error --> syntax error, unexpected 'foreach' (T_FOREACH) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 6
ERROR - 2023-09-03 11:18:31 --> Severity: Parsing Error --> syntax error, unexpected '.' D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 6
ERROR - 2023-09-03 11:18:57 --> Severity: Parsing Error --> syntax error, unexpected 'foreach' (T_FOREACH) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 6
ERROR - 2023-09-03 11:18:58 --> Severity: Parsing Error --> syntax error, unexpected 'foreach' (T_FOREACH) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 6
ERROR - 2023-09-03 11:18:58 --> Severity: Parsing Error --> syntax error, unexpected 'foreach' (T_FOREACH) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 6
ERROR - 2023-09-03 11:18:59 --> Severity: Parsing Error --> syntax error, unexpected 'foreach' (T_FOREACH) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 6
ERROR - 2023-09-03 11:18:59 --> Severity: Parsing Error --> syntax error, unexpected 'foreach' (T_FOREACH) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 6
ERROR - 2023-09-03 11:18:59 --> Severity: Parsing Error --> syntax error, unexpected 'foreach' (T_FOREACH) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 6
ERROR - 2023-09-03 11:18:59 --> Severity: Parsing Error --> syntax error, unexpected 'foreach' (T_FOREACH) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 6
ERROR - 2023-09-03 11:19:00 --> Severity: Parsing Error --> syntax error, unexpected 'foreach' (T_FOREACH) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 6
ERROR - 2023-09-03 11:24:54 --> Severity: Parsing Error --> syntax error, unexpected ''.foreach($survey as $key=>$va' (T_CONSTANT_ENCAPSED_STRING) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 6
ERROR - 2023-09-03 11:24:55 --> Severity: Parsing Error --> syntax error, unexpected ''.foreach($survey as $key=>$va' (T_CONSTANT_ENCAPSED_STRING) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 6
ERROR - 2023-09-03 11:24:55 --> Severity: Parsing Error --> syntax error, unexpected ''.foreach($survey as $key=>$va' (T_CONSTANT_ENCAPSED_STRING) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 6
ERROR - 2023-09-03 11:24:56 --> Severity: Parsing Error --> syntax error, unexpected ''.foreach($survey as $key=>$va' (T_CONSTANT_ENCAPSED_STRING) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 6
ERROR - 2023-09-03 11:24:56 --> Severity: Parsing Error --> syntax error, unexpected ''.foreach($survey as $key=>$va' (T_CONSTANT_ENCAPSED_STRING) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 6
ERROR - 2023-09-03 11:24:56 --> Severity: Parsing Error --> syntax error, unexpected ''.foreach($survey as $key=>$va' (T_CONSTANT_ENCAPSED_STRING) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 6
ERROR - 2023-09-03 11:25:45 --> Severity: Parsing Error --> syntax error, unexpected '"' D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 6
ERROR - 2023-09-03 11:25:46 --> Severity: Parsing Error --> syntax error, unexpected '"' D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 6
ERROR - 2023-09-03 11:25:46 --> Severity: Parsing Error --> syntax error, unexpected '"' D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 6
ERROR - 2023-09-03 11:25:54 --> Severity: Parsing Error --> syntax error, unexpected 'foreach' (T_FOREACH) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 6
ERROR - 2023-09-03 11:26:03 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 10
ERROR - 2023-09-03 11:26:04 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 10
ERROR - 2023-09-03 11:26:04 --> Severity: Parsing Error --> syntax error, unexpected '}' D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 10
ERROR - 2023-09-03 11:27:19 --> Severity: Parsing Error --> syntax error, unexpected '<' D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 12
ERROR - 2023-09-03 11:50:20 --> Severity: Parsing Error --> syntax error, unexpected 'generate' (T_STRING) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 8
ERROR - 2023-09-03 11:50:21 --> Severity: Parsing Error --> syntax error, unexpected 'generate' (T_STRING) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 8
ERROR - 2023-09-03 11:50:21 --> Severity: Parsing Error --> syntax error, unexpected 'generate' (T_STRING) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 8
ERROR - 2023-09-03 11:50:22 --> Severity: Parsing Error --> syntax error, unexpected 'generate' (T_STRING) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 8
ERROR - 2023-09-03 11:50:22 --> Severity: Parsing Error --> syntax error, unexpected 'generate' (T_STRING) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 8
ERROR - 2023-09-03 11:50:39 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 8
ERROR - 2023-09-03 11:50:40 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 8
ERROR - 2023-09-03 11:50:40 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 8
ERROR - 2023-09-03 11:52:07 --> Severity: Parsing Error --> syntax error, unexpected 'foreach' (T_FOREACH) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 5
ERROR - 2023-09-03 11:52:19 --> Severity: Parsing Error --> syntax error, unexpected '/' D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 10
ERROR - 2023-09-03 11:52:44 --> Severity: Parsing Error --> syntax error, unexpected '/' D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 10
ERROR - 2023-09-03 11:53:26 --> Severity: Parsing Error --> syntax error, unexpected '$html2' (T_VARIABLE) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 10
ERROR - 2023-09-03 11:53:27 --> Severity: Parsing Error --> syntax error, unexpected '$html2' (T_VARIABLE) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 10
ERROR - 2023-09-03 11:53:27 --> Severity: Parsing Error --> syntax error, unexpected '$html2' (T_VARIABLE) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 10
ERROR - 2023-09-03 11:53:37 --> 404 Page Not Found: Generate/index
ERROR - 2023-09-03 11:53:37 --> 404 Page Not Found: Generate/index
ERROR - 2023-09-03 11:53:37 --> 404 Page Not Found: Generate/index
ERROR - 2023-09-03 11:54:43 --> Severity: Parsing Error --> syntax error, unexpected 'foreach' (T_FOREACH) D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 5
ERROR - 2023-09-03 11:55:09 --> 404 Page Not Found: Generate/index
ERROR - 2023-09-03 11:55:09 --> 404 Page Not Found: Generate/index
ERROR - 2023-09-03 11:55:09 --> 404 Page Not Found: Generate/index
ERROR - 2023-09-03 11:55:26 --> 404 Page Not Found: Generate/index
ERROR - 2023-09-03 11:55:26 --> 404 Page Not Found: Generate/index
ERROR - 2023-09-03 11:55:26 --> 404 Page Not Found: Generate/index
ERROR - 2023-09-03 11:58:38 --> Severity: Parsing Error --> syntax error, unexpected '=' D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 7
ERROR - 2023-09-03 12:00:22 --> Severity: Parsing Error --> syntax error, unexpected end of file D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 95
ERROR - 2023-09-03 12:00:44 --> Severity: Parsing Error --> syntax error, unexpected '/' D:\wamp3.2.6\www\barcode\application\views\barcodeview_pdf.php 37
