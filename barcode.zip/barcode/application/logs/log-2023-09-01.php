<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-01 05:32:29 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 05:32:29 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 05:32:29 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 05:32:29 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 05:32:29 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 05:32:29 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 05:32:29 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 05:32:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 05:32:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 05:32:44 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 05:32:44 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 05:32:44 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 05:32:44 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 05:32:44 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 05:32:44 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 05:32:44 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 05:32:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 05:32:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 05:33:26 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 05:33:26 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 05:33:26 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 05:33:26 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 05:33:26 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 05:33:26 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 05:33:26 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 05:33:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 05:33:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 06:20:53 --> 404 Page Not Found: Generate/index
ERROR - 2023-09-01 06:30:21 --> 404 Page Not Found: Generate/index
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:36:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php:199) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-09-01 06:53:18 --> 404 Page Not Found: Generate/index
ERROR - 2023-09-01 09:43:40 --> Severity: error --> Exception: Call to undefined function base_url() D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 68
ERROR - 2023-09-01 09:51:15 --> 404 Page Not Found: BarPrint/viewpage
ERROR - 2023-09-01 10:02:40 --> Severity: Warning --> preg_match() expects parameter 2 to be string, object given D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 23088
ERROR - 2023-09-01 10:02:40 --> Severity: error --> Exception: Object of class CI_Loader could not be converted to string D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 30894
ERROR - 2023-09-01 10:02:59 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:02:59 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:02:59 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:02:59 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:02:59 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:02:59 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:02:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\otl.php 5377
ERROR - 2023-09-01 10:02:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\otl.php 5377
ERROR - 2023-09-01 10:02:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\otl.php 5377
ERROR - 2023-09-01 10:02:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\otl.php 5377
ERROR - 2023-09-01 10:02:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\otl.php 5377
ERROR - 2023-09-01 10:02:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\otl.php 5377
ERROR - 2023-09-01 10:02:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\otl.php 5377
ERROR - 2023-09-01 10:02:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\otl.php 5377
ERROR - 2023-09-01 10:02:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\otl.php 5377
ERROR - 2023-09-01 10:02:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\otl.php 5377
ERROR - 2023-09-01 10:02:59 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:02:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 10:02:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:04:19 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:04:19 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:04:19 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:04:19 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:04:19 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:04:19 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:04:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\otl.php 5377
ERROR - 2023-09-01 10:04:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\otl.php 5377
ERROR - 2023-09-01 10:04:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\otl.php 5377
ERROR - 2023-09-01 10:04:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\otl.php 5377
ERROR - 2023-09-01 10:04:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\otl.php 5377
ERROR - 2023-09-01 10:04:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\otl.php 5377
ERROR - 2023-09-01 10:04:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\otl.php 5377
ERROR - 2023-09-01 10:04:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\otl.php 5377
ERROR - 2023-09-01 10:04:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\otl.php 5377
ERROR - 2023-09-01 10:04:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\otl.php 5377
ERROR - 2023-09-01 10:04:19 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:04:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 10:04:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:06:06 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:06:06 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:06:06 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:06:06 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:06:06 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:06:06 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:06:06 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:06:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 10:06:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:06:08 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:06:08 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:06:08 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:06:08 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:06:08 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:06:08 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:06:08 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:06:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 10:06:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:06:08 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:06:08 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:06:08 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:06:08 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:06:08 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:06:08 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:06:08 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:06:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 10:06:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:13:07 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:07 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:07 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:07 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:07 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:07 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:07 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:13:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 10:13:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:13:09 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:09 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:09 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:09 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:09 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:09 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:09 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:13:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 10:13:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:13:09 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:09 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:09 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:09 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:09 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:09 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:09 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:13:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 10:13:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:13:09 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:09 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:09 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:09 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:09 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:09 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:09 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:13:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 10:13:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:13:09 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:09 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:09 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:09 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:09 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:09 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:09 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:13:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 10:13:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:13:10 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:10 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:10 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:10 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:10 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:10 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:10 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:13:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 10:13:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:13:10 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:10 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:10 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:10 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:10 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:10 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:10 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:13:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 10:13:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:13:10 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:10 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:10 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:10 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:10 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:10 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:11 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:13:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 10:13:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:13:11 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:11 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:11 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:11 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:11 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:11 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:11 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:13:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 10:13:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:13:33 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:33 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:33 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:33 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:33 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:33 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:33 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:13:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8314
ERROR - 2023-09-01 10:13:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:13:36 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:36 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:36 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:36 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:36 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:36 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:36 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:13:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8314
ERROR - 2023-09-01 10:13:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:13:37 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:37 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:37 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:37 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:37 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:37 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:37 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:13:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8314
ERROR - 2023-09-01 10:13:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:13:37 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:37 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:37 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:37 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:37 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:37 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:37 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:13:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8314
ERROR - 2023-09-01 10:13:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:13:37 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:37 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:37 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:37 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:37 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:37 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:37 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:13:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8314
ERROR - 2023-09-01 10:13:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:13:38 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:38 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:38 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:38 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:38 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:38 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:38 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:13:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8314
ERROR - 2023-09-01 10:13:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:13:38 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:38 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:38 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:38 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:38 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:38 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:38 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:13:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8314
ERROR - 2023-09-01 10:13:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:13:39 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:39 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:39 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:39 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:39 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:39 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:39 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:13:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8314
ERROR - 2023-09-01 10:13:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:13:39 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:39 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:39 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:39 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:39 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:39 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:39 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:13:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8314
ERROR - 2023-09-01 10:13:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:13:39 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:39 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:39 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:39 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:39 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:39 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:39 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:13:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8314
ERROR - 2023-09-01 10:13:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:13:40 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:40 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:40 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:40 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:40 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:40 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:40 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:13:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8314
ERROR - 2023-09-01 10:13:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:13:40 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:40 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:13:40 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:40 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:13:40 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:40 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:13:40 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:13:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8314
ERROR - 2023-09-01 10:13:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:14:45 --> Unable to load the requested class: Mpdf
ERROR - 2023-09-01 10:15:33 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:15:33 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:15:33 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:15:33 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:15:33 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:15:33 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:15:33 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:15:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 10:15:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:15:44 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:15:44 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:15:44 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:15:44 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:15:44 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:15:44 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:15:44 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:15:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 10:15:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:15:44 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:15:44 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:15:44 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:15:44 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:15:44 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:15:44 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:15:45 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:15:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 10:15:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:15:45 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:15:45 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:15:45 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:15:45 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:15:45 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:15:45 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:15:45 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:15:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 10:15:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:16:11 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:16:11 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:16:11 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:16:11 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:16:11 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:16:11 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:16:11 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:16:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 10:16:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:19:15 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:19:15 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:19:15 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:19:15 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:19:15 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:19:15 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:19:15 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:19:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 10:19:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:19:16 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:19:16 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:19:16 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:19:16 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:19:16 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:19:16 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:19:16 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:19:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 10:19:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:19:16 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:19:16 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:19:16 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:19:16 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:19:16 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:19:16 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:19:16 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:19:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 10:19:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:19:17 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:19:17 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 10:19:17 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:19:17 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 10:19:17 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:19:17 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 10:19:17 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 10:19:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 10:19:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 10:37:39 --> Severity: error --> Exception: syntax error, unexpected '.1000' (T_DNUMBER), expecting ')' D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 66
ERROR - 2023-09-01 10:38:48 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 67
ERROR - 2023-09-01 10:38:49 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 67
ERROR - 2023-09-01 10:38:49 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 67
ERROR - 2023-09-01 10:38:49 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 67
ERROR - 2023-09-01 10:39:27 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 67
ERROR - 2023-09-01 10:40:25 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 33
ERROR - 2023-09-01 10:40:26 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 33
ERROR - 2023-09-01 10:40:26 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 33
ERROR - 2023-09-01 10:40:57 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 33
ERROR - 2023-09-01 10:40:58 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 33
ERROR - 2023-09-01 10:40:58 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 33
ERROR - 2023-09-01 10:40:59 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 33
ERROR - 2023-09-01 10:40:59 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 33
ERROR - 2023-09-01 10:40:59 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 33
ERROR - 2023-09-01 10:40:59 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 33
ERROR - 2023-09-01 10:41:00 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 33
ERROR - 2023-09-01 10:41:00 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 33
ERROR - 2023-09-01 10:41:00 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 33
ERROR - 2023-09-01 10:41:00 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 33
ERROR - 2023-09-01 10:41:33 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 34
ERROR - 2023-09-01 10:41:33 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 34
ERROR - 2023-09-01 10:41:33 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 34
ERROR - 2023-09-01 10:42:45 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 34
ERROR - 2023-09-01 10:43:32 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 34
ERROR - 2023-09-01 10:43:33 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 34
ERROR - 2023-09-01 10:43:33 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 34
ERROR - 2023-09-01 10:43:33 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 34
ERROR - 2023-09-01 10:43:33 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 34
ERROR - 2023-09-01 10:43:34 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 34
ERROR - 2023-09-01 10:43:34 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 34
ERROR - 2023-09-01 10:43:34 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 34
ERROR - 2023-09-01 10:43:35 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 34
ERROR - 2023-09-01 10:43:35 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 34
ERROR - 2023-09-01 10:43:35 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 34
ERROR - 2023-09-01 10:43:35 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 34
ERROR - 2023-09-01 10:43:36 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 34
ERROR - 2023-09-01 10:43:36 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 34
ERROR - 2023-09-01 10:43:36 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 34
ERROR - 2023-09-01 10:43:36 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 34
ERROR - 2023-09-01 10:43:37 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 34
ERROR - 2023-09-01 10:44:38 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 34
ERROR - 2023-09-01 10:44:39 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 34
ERROR - 2023-09-01 10:44:39 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 34
ERROR - 2023-09-01 10:44:39 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 34
ERROR - 2023-09-01 10:44:40 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 34
ERROR - 2023-09-01 10:44:40 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 34
ERROR - 2023-09-01 10:44:40 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 34
ERROR - 2023-09-01 10:45:06 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 10:45:56 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 10:45:57 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 10:45:57 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 10:46:11 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 40
ERROR - 2023-09-01 10:46:12 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 40
ERROR - 2023-09-01 10:46:12 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 40
ERROR - 2023-09-01 10:46:13 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 40
ERROR - 2023-09-01 10:48:33 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 40
ERROR - 2023-09-01 10:48:34 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 40
ERROR - 2023-09-01 10:48:34 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 40
ERROR - 2023-09-01 10:48:35 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 40
ERROR - 2023-09-01 10:48:35 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 40
ERROR - 2023-09-01 10:48:35 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 40
ERROR - 2023-09-01 10:48:35 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 40
ERROR - 2023-09-01 10:48:35 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 40
ERROR - 2023-09-01 10:49:04 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 40
ERROR - 2023-09-01 10:49:06 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 40
ERROR - 2023-09-01 10:49:06 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 40
ERROR - 2023-09-01 10:50:27 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 40
ERROR - 2023-09-01 10:50:28 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 40
ERROR - 2023-09-01 10:50:28 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 40
ERROR - 2023-09-01 10:50:28 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 40
ERROR - 2023-09-01 10:51:06 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 40
ERROR - 2023-09-01 10:51:07 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 40
ERROR - 2023-09-01 10:51:07 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 40
ERROR - 2023-09-01 10:51:08 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 40
ERROR - 2023-09-01 10:51:08 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 40
ERROR - 2023-09-01 10:51:08 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 40
ERROR - 2023-09-01 10:53:49 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 10:53:51 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 10:55:17 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 10:55:18 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 10:55:18 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 10:59:07 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 10:59:08 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 10:59:09 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 10:59:09 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 10:59:31 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 10:59:50 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 10:59:51 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 10:59:51 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 10:59:52 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 11:00:22 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 11:00:23 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 11:00:23 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 11:00:24 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 11:00:24 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 11:00:24 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 11:01:10 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 11:01:25 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 11:01:26 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 11:01:26 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 11:01:26 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 11:01:27 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 11:02:02 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 11:02:03 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 11:02:03 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 11:03:13 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 11:03:16 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 36
ERROR - 2023-09-01 11:03:29 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 40
ERROR - 2023-09-01 11:03:40 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 44
ERROR - 2023-09-01 11:04:22 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 41
ERROR - 2023-09-01 11:04:23 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 41
ERROR - 2023-09-01 11:04:23 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 41
ERROR - 2023-09-01 11:04:23 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 41
ERROR - 2023-09-01 11:04:45 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 44
ERROR - 2023-09-01 11:04:56 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 44
ERROR - 2023-09-01 11:09:07 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 44
ERROR - 2023-09-01 11:09:34 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 44
ERROR - 2023-09-01 11:09:58 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 46
ERROR - 2023-09-01 11:10:40 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 48
ERROR - 2023-09-01 11:10:41 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 48
ERROR - 2023-09-01 11:10:41 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 48
ERROR - 2023-09-01 11:10:41 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 48
ERROR - 2023-09-01 11:10:41 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 48
ERROR - 2023-09-01 11:10:42 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 48
ERROR - 2023-09-01 11:10:42 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 48
ERROR - 2023-09-01 11:10:42 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 48
ERROR - 2023-09-01 11:10:42 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 48
ERROR - 2023-09-01 11:10:44 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 48
ERROR - 2023-09-01 11:10:44 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 48
ERROR - 2023-09-01 11:10:45 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 48
ERROR - 2023-09-01 11:11:54 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 51
ERROR - 2023-09-01 11:14:21 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 51
ERROR - 2023-09-01 11:16:27 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 52
ERROR - 2023-09-01 11:17:57 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 55
ERROR - 2023-09-01 11:18:15 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 55
ERROR - 2023-09-01 11:18:32 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 55
ERROR - 2023-09-01 11:19:30 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 56
ERROR - 2023-09-01 11:19:50 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 56
ERROR - 2023-09-01 11:19:58 --> Severity: Notice --> Undefined variable: value D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 56
ERROR - 2023-09-01 11:49:45 --> Severity: Notice --> Undefined property: Platform::$survey_mdl D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 43
ERROR - 2023-09-01 11:49:45 --> Severity: error --> Exception: Call to a member function get_barcodeList() on null D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 43
ERROR - 2023-09-01 11:50:12 --> Severity: Notice --> Undefined property: Platform::$db D:\wamp3.2.6\www\barcode\system\core\Model.php 74
ERROR - 2023-09-01 11:50:12 --> Severity: error --> Exception: Call to a member function query() on null D:\wamp3.2.6\www\barcode\application\models\Survey_mdl.php 10
ERROR - 2023-09-01 11:53:11 --> Severity: Notice --> Undefined property: Platform::$db D:\wamp3.2.6\www\barcode\system\core\Model.php 74
ERROR - 2023-09-01 11:53:11 --> Severity: error --> Exception: Call to a member function query() on null D:\wamp3.2.6\www\barcode\application\models\Survey_mdl.php 10
ERROR - 2023-09-01 11:54:44 --> Severity: Notice --> Undefined property: Platform::$db D:\wamp3.2.6\www\barcode\system\core\Model.php 74
ERROR - 2023-09-01 11:54:44 --> Severity: error --> Exception: Call to a member function query() on null D:\wamp3.2.6\www\barcode\application\models\Survey_mdl.php 10
ERROR - 2023-09-01 11:54:45 --> Severity: Notice --> Undefined property: Platform::$db D:\wamp3.2.6\www\barcode\system\core\Model.php 74
ERROR - 2023-09-01 11:54:45 --> Severity: error --> Exception: Call to a member function query() on null D:\wamp3.2.6\www\barcode\application\models\Survey_mdl.php 10
ERROR - 2023-09-01 11:54:45 --> Severity: Notice --> Undefined property: Platform::$db D:\wamp3.2.6\www\barcode\system\core\Model.php 74
ERROR - 2023-09-01 11:54:45 --> Severity: error --> Exception: Call to a member function query() on null D:\wamp3.2.6\www\barcode\application\models\Survey_mdl.php 10
ERROR - 2023-09-01 11:57:54 --> Severity: error --> Exception: Object of class stdClass could not be converted to string D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 58
ERROR - 2023-09-01 11:59:05 --> Severity: Notice --> Array to string conversion D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 44
ERROR - 2023-09-01 11:59:32 --> Severity: Notice --> Array to string conversion D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 44
ERROR - 2023-09-01 11:59:34 --> Severity: Notice --> Array to string conversion D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 44
ERROR - 2023-09-01 11:59:34 --> Severity: Notice --> Array to string conversion D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 44
ERROR - 2023-09-01 11:59:34 --> Severity: Notice --> Array to string conversion D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 44
ERROR - 2023-09-01 11:59:34 --> Severity: Notice --> Array to string conversion D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 44
ERROR - 2023-09-01 11:59:35 --> Severity: Notice --> Array to string conversion D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 44
ERROR - 2023-09-01 11:59:35 --> Severity: Notice --> Array to string conversion D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 44
ERROR - 2023-09-01 11:59:35 --> Severity: Notice --> Array to string conversion D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 44
ERROR - 2023-09-01 12:00:04 --> Severity: Notice --> Undefined property: Platform::$db D:\wamp3.2.6\www\barcode\system\core\Model.php 74
ERROR - 2023-09-01 12:00:04 --> Severity: error --> Exception: Call to a member function query() on null D:\wamp3.2.6\www\barcode\application\models\Survey_mdl.php 10
ERROR - 2023-09-01 12:00:31 --> Severity: Notice --> Array to string conversion D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 44
ERROR - 2023-09-01 12:00:32 --> Severity: Notice --> Array to string conversion D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 44
ERROR - 2023-09-01 12:00:32 --> Severity: Notice --> Array to string conversion D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 44
ERROR - 2023-09-01 12:00:52 --> Severity: error --> Exception: Object of class stdClass could not be converted to string D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 58
ERROR - 2023-09-01 12:01:29 --> Severity: error --> Exception: Object of class stdClass could not be converted to string D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 58
ERROR - 2023-09-01 12:01:30 --> Severity: error --> Exception: Object of class stdClass could not be converted to string D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 58
ERROR - 2023-09-01 12:01:30 --> Severity: error --> Exception: Object of class stdClass could not be converted to string D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 58
ERROR - 2023-09-01 12:01:30 --> Severity: error --> Exception: Object of class stdClass could not be converted to string D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 58
ERROR - 2023-09-01 12:05:52 --> Severity: error --> Exception: Object of class stdClass could not be converted to string D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 58
ERROR - 2023-09-01 12:06:08 --> Severity: Notice --> Array to string conversion D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 45
ERROR - 2023-09-01 12:06:47 --> Severity: error --> Exception: Object of class stdClass could not be converted to string D:\wamp3.2.6\www\barcode\application\views\barcodeview.php 58
ERROR - 2023-09-01 12:10:36 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 12:10:36 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 12:10:36 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 12:10:36 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 12:10:36 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 12:10:36 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 12:10:37 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 12:10:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 12:10:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 12:16:56 --> Severity: error --> Exception: Call to a member function query() on null D:\wamp3.2.6\www\barcode\application\models\Survey_mdl.php 11
ERROR - 2023-09-01 13:05:49 --> 404 Page Not Found: Mpdfp/index
ERROR - 2023-09-01 13:06:34 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 13:06:34 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 13:06:34 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 13:06:34 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 13:06:34 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 13:06:34 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 13:06:34 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 13:06:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 13:06:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 13:12:16 --> Severity: error --> Exception: Class 'Mpdf\Mpdf' not found D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 52
ERROR - 2023-09-01 13:17:18 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 13:17:18 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 13:17:18 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 13:17:18 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 13:17:18 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 13:17:18 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 13:17:18 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 13:17:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 13:17:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 13:18:17 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 13:18:17 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 13:18:17 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 13:18:17 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 13:18:17 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 13:18:17 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 13:18:17 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-09-01 13:18:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 13:18:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 13:18:57 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 13:18:57 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 13:18:57 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 13:18:57 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 13:18:57 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 13:18:57 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 13:18:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 13:18:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 13:19:00 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 13:19:00 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-09-01 13:19:00 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 13:19:00 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-09-01 13:19:00 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 13:19:00 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-09-01 13:19:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 13:19:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 13:19:28 --> 404 Page Not Found: Platform/mpdfp
ERROR - 2023-09-01 13:19:46 --> 404 Page Not Found: Viewpage/index
ERROR - 2023-09-01 13:22:16 --> Severity: Warning --> preg_match() expects parameter 2 to be string, object given D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 23088
ERROR - 2023-09-01 13:22:16 --> Severity: Warning --> mb_convert_encoding() expects parameter 1 to be string, object given D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 30894
ERROR - 2023-09-01 13:22:16 --> Severity: Warning --> mb_convert_encoding() expects parameter 1 to be string, object given D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 30917
ERROR - 2023-09-01 13:22:16 --> Severity: Warning --> iconv() expects parameter 3 to be string, object given D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 30918
ERROR - 2023-09-01 13:22:16 --> Severity: Warning --> substr() expects parameter 1 to be string, object given D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 30922
ERROR - 2023-09-01 13:22:16 --> Severity: Warning --> substr() expects parameter 1 to be string, object given D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 30927
ERROR - 2023-09-01 13:22:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 13:30:07 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 36
ERROR - 2023-09-01 13:30:42 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1124
ERROR - 2023-09-01 13:30:42 --> Severity: Warning --> strlen() expects parameter 1 to be string, array given D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1130
ERROR - 2023-09-01 13:30:42 --> Severity: Warning --> substr() expects parameter 1 to be string, array given D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1134
ERROR - 2023-09-01 13:30:42 --> Severity: Warning --> substr() expects parameter 1 to be string, array given D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1138
ERROR - 2023-09-01 13:30:42 --> Severity: Warning --> substr() expects parameter 1 to be string, array given D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1142
ERROR - 2023-09-01 13:30:42 --> Severity: Warning --> preg_split() expects parameter 2 to be string, array given D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\config_lang2fonts.php 19
ERROR - 2023-09-01 13:31:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 13:31:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 13:32:11 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1124
ERROR - 2023-09-01 13:32:11 --> Severity: Warning --> strlen() expects parameter 1 to be string, array given D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1130
ERROR - 2023-09-01 13:32:11 --> Severity: Warning --> substr() expects parameter 1 to be string, array given D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1134
ERROR - 2023-09-01 13:32:11 --> Severity: Warning --> substr() expects parameter 1 to be string, array given D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1138
ERROR - 2023-09-01 13:32:11 --> Severity: Warning --> substr() expects parameter 1 to be string, array given D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1142
ERROR - 2023-09-01 13:32:11 --> Severity: Warning --> preg_split() expects parameter 2 to be string, array given D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\config_lang2fonts.php 19
ERROR - 2023-09-01 13:32:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-09-01 13:32:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-09-01 13:56:08 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 50
ERROR - 2023-09-01 13:56:46 --> Severity: Error --> Unsupported operand types D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 3698
ERROR - 2023-09-01 13:57:08 --> Severity: Error --> Unsupported operand types D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 3698
ERROR - 2023-09-01 13:57:09 --> Severity: Error --> Unsupported operand types D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 3698
ERROR - 2023-09-01 13:57:09 --> Severity: Error --> Unsupported operand types D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 3698
ERROR - 2023-09-01 13:57:10 --> Severity: Error --> Unsupported operand types D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 3698
ERROR - 2023-09-01 13:57:10 --> Severity: Error --> Unsupported operand types D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 3698
ERROR - 2023-09-01 13:57:11 --> Severity: Error --> Unsupported operand types D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 3698
