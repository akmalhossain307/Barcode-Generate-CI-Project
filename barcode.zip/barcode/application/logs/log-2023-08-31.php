<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-31 20:58:37 --> 404 Page Not Found: Generate/index
ERROR - 2023-08-31 20:58:38 --> 404 Page Not Found: Generate/index
ERROR - 2023-08-31 20:58:39 --> 404 Page Not Found: Generate/index
ERROR - 2023-08-31 21:00:58 --> 404 Page Not Found: Generate/index
ERROR - 2023-08-31 15:35:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Object\ObjectAbstract.php:705) D:\wamp3.2.6\www\barcode\application\libraries\Zend\Barcode\Renderer\Image.php 197
ERROR - 2023-08-31 16:27:33 --> Severity: error --> Exception: Call to undefined function base_url() D:\wamp3.2.6\www\barcode\application\views\index.php 11
ERROR - 2023-08-31 16:27:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\otl.php:2874) D:\wamp3.2.6\www\barcode\system\core\Common.php 571
ERROR - 2023-08-31 16:27:34 --> Severity: error --> Exception: Call to undefined function base_url() D:\wamp3.2.6\www\barcode\application\views\index.php 11
ERROR - 2023-08-31 16:27:34 --> Severity: error --> Exception: Call to undefined function base_url() D:\wamp3.2.6\www\barcode\application\views\index.php 11
ERROR - 2023-08-31 16:27:37 --> Severity: error --> Exception: Call to undefined function base_url() D:\wamp3.2.6\www\barcode\application\views\index.php 11
ERROR - 2023-08-31 16:27:38 --> Severity: error --> Exception: Call to undefined function base_url() D:\wamp3.2.6\www\barcode\application\views\index.php 11
ERROR - 2023-08-31 16:27:38 --> Severity: error --> Exception: Call to undefined function base_url() D:\wamp3.2.6\www\barcode\application\views\index.php 11
ERROR - 2023-08-31 16:36:26 --> Severity: error --> Exception: Class 'Mpdf\Mpdf' not found D:\wamp3.2.6\www\barcode\application\controllers\Platform.php 12
ERROR - 2023-08-31 16:36:44 --> Severity: error --> Exception: Call to undefined function base_url() D:\wamp3.2.6\www\barcode\application\views\index.php 11
ERROR - 2023-08-31 16:36:45 --> Severity: error --> Exception: Call to undefined function base_url() D:\wamp3.2.6\www\barcode\application\views\index.php 11
ERROR - 2023-08-31 16:36:49 --> Severity: error --> Exception: Call to undefined function base_url() D:\wamp3.2.6\www\barcode\application\views\index.php 11
ERROR - 2023-08-31 16:37:30 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-08-31 16:37:30 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-08-31 16:37:30 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-08-31 16:37:30 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-08-31 16:37:30 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-08-31 16:37:30 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-08-31 16:37:31 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-08-31 16:37:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-08-31 16:37:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-08-31 16:38:10 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-08-31 16:38:10 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-08-31 16:38:10 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-08-31 16:38:10 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-08-31 16:38:10 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-08-31 16:38:10 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-08-31 16:38:11 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-08-31 16:38:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-08-31 16:38:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-08-31 16:38:12 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-08-31 16:38:12 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-08-31 16:38:12 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-08-31 16:38:12 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-08-31 16:38:12 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-08-31 16:38:12 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-08-31 16:38:12 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-08-31 16:38:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-08-31 16:38:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-08-31 16:38:13 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-08-31 16:38:13 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-08-31 16:38:13 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-08-31 16:38:13 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-08-31 16:38:13 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-08-31 16:38:13 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-08-31 16:38:13 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-08-31 16:38:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-08-31 16:38:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-08-31 16:41:05 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-08-31 16:41:05 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-08-31 16:41:05 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-08-31 16:41:05 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-08-31 16:41:05 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-08-31 16:41:05 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-08-31 16:41:06 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-08-31 16:41:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-08-31 16:41:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-08-31 16:41:07 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-08-31 16:41:07 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-08-31 16:41:07 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-08-31 16:41:07 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-08-31 16:41:07 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-08-31 16:41:07 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-08-31 16:41:07 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-08-31 16:41:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-08-31 16:41:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-08-31 16:41:08 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-08-31 16:41:08 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-08-31 16:41:08 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-08-31 16:41:08 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-08-31 16:41:08 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-08-31 16:41:08 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-08-31 16:41:08 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-08-31 16:41:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-08-31 16:41:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-08-31 16:41:08 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-08-31 16:41:08 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-08-31 16:41:08 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-08-31 16:41:08 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-08-31 16:41:08 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-08-31 16:41:08 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-08-31 16:41:08 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-08-31 16:41:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-08-31 16:41:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-08-31 16:41:08 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-08-31 16:41:08 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-08-31 16:41:08 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-08-31 16:41:08 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-08-31 16:41:08 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-08-31 16:41:08 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-08-31 16:41:09 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-08-31 16:41:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-08-31 16:41:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
ERROR - 2023-08-31 16:43:02 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-08-31 16:43:02 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1136
ERROR - 2023-08-31 16:43:02 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-08-31 16:43:02 --> Severity: Warning --> Cannot assign an empty string to a string offset D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1139
ERROR - 2023-08-31 16:43:02 --> Severity: Warning --> Illegal string offset 'ID' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-08-31 16:43:02 --> Severity: Warning --> Illegal string offset 'LANG' D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\classes\cssmgr.php 1190
ERROR - 2023-08-31 16:43:02 --> Severity: 8192 --> The each() function is deprecated. This message will be suppressed on further calls D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 9665
ERROR - 2023-08-31 16:43:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 8297
ERROR - 2023-08-31 16:43:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wamp3.2.6\www\barcode\system\core\Exceptions.php:272) D:\wamp3.2.6\www\barcode\application\libraries\Mpdf\Mpdf.php 1706
