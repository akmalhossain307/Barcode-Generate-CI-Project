<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

require_once 'Zend/Exception.php';

class Zend_Barcode_Exception extends Zend_Exception
{
	protected $_isRenderable = true;
	
	public function setIsRenderable($flag)
	{
		$this->_isRenderable = (bool) $flag;
		return $this;
	}
	
	public function isRenderable()
	{
		return $this->_isRenderable;
	}
}

/* End of file Exception.php */
/* Location: ./cmv/libraries/Zend/Barcode/Exception.php */