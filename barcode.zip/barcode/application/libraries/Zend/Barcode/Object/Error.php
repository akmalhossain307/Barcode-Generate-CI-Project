<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

require_once 'Zend/Barcode/Object/ObjectAbstract.php';

class Zend_Barcode_Object_Error extends Zend_Barcode_Object_ObjectAbstract
{	
	public function validateText($value)
	{
		return true;
	}
	
	public function getHeight($recalculate = false)
	{
		return 40;
	}

	public function getWidth($recalculate = false)
	{
		return 400;
	}

	public function draw()
	{
		$this->_instructions = array();
		$this->_addText('ERROR:', 10, array(5 , 18), $this->_font, 0, 'left');
		$this->_addText($this->_text, 10, array(5 , 32), $this->_font, 0, 'left');
		return $this->_instructions;
	}

	protected function _prepareBarcode()
	{
	}

	protected function _checkParams()
	{
	}
	
	protected function _calculateBarcodeWidth()
	{
	}
}

/* End of file Error.php */
/* Location: ./cmv/libraries/Zend/Barcode/Object/Error.php */