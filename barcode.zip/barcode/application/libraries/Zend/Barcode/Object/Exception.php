<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

require_once 'Zend/Barcode/Exception.php';

class Zend_Barcode_Object_Exception extends Zend_Barcode_Exception
{
}

/* End of file Exception.php */
/* Location: ./cmv/libraries/Zend/Barcode/Object/Exception.php */