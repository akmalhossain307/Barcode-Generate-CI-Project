<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Zend_Loader
{
	public static function loadClass($class, $dirs = null)
	{
		if (class_exists($class, false) || interface_exists($class, false))
		{
			return;
		}
		
		if ((null !== $dirs) && !is_string($dirs) && !is_array($dirs))
		{
			require_once 'Zend/Exception.php';
			throw new Zend_Exception('Directory argument must be a string or an array');
		}
		
		$file = self::standardiseFile($class);
		
		if (!empty($dirs))
		{
			$dirPath = dirname($file);
			if (is_string($dirs))
			{
				$dirs = explode(PATH_SEPARATOR, $dirs);
			}
			foreach ($dirs as $key => $dir)
			{
				if ($dir == '.')
				{
					$dirs[$key] = $dirPath;
				}
				else
				{
					$dir = rtrim($dir, '\\/');
					$dirs[$key] = $dir . DIRECTORY_SEPARATOR . $dirPath;
				}
			}
			$file = basename($file);
			self::loadFile($file, $dirs, true);
		}
		else
		{
			self::loadFile($file, null, true);
		}
		
		if (!class_exists($class, false) && !interface_exists($class, false))
		{
			require_once 'Zend/Exception.php';
			throw new Zend_Exception("File \"$file\" does not exist or class \"$class\" was not found in the file");
		}
	}
	
	public static function loadFile($filename, $dirs = null, $once = false)
	{
		self::_securityCheck($filename);
		
		$incPath = false;
		if (!empty($dirs) && (is_array($dirs) || is_string($dirs)))
		{
			if (is_array($dirs))
			{
				$dirs = implode(PATH_SEPARATOR, $dirs);
			}
			$incPath = get_include_path();
			set_include_path($dirs . PATH_SEPARATOR . $incPath);
		}
		
		if ($once)
		{
			include_once $filename;
		}
		else
		{
			include $filename;
		}
		
		if ($incPath)
		{
			set_include_path($incPath);
		}
		
		return true;
	}
	
	public static function isReadable($filename)
	{
		if (is_readable($filename))
		{
			return true;
		}
		
		if (strtoupper(substr(PHP_OS, 0, 3)) == 'WIN' && preg_match('/^[a-z]:/i', $filename))
		{
			return false;
		}
		
		foreach (self::explodeIncludePath() as $path)
		{
			if ($path == '.')
			{
				if (is_readable($filename))
				{
					return true;
				}
				continue;
			}
			$file = $path . '/' . $filename;
			if (is_readable($file))
			{
				return true;
			}
		}
		return false;
	}
	
	public static function explodeIncludePath($path = null)
	{
		if (null === $path)
		{
			$path = get_include_path();
		}
		
		if (PATH_SEPARATOR == ':')
		{
			$paths = preg_split('#:(?!//)#', $path);
		}
		else
		{
			$paths = explode(PATH_SEPARATOR, $path);
		}
		return $paths;
	}
	
	public static function autoload($class)
	{
		trigger_error(__CLASS__ . '::' . __METHOD__ . ' is deprecated as of 1.8.0 and will be removed with 2.0.0; use Zend_Loader_Autoloader instead', E_USER_NOTICE);
		try
		{
			@self::loadClass($class);
			return $class;
		}
		catch (Exception $e)
		{
			return false;
		}
	}
	
	public static function registerAutoload($class = 'Zend_Loader', $enabled = true)
	{
		trigger_error(__CLASS__ . '::' . __METHOD__ . ' is deprecated as of 1.8.0 and will be removed with 2.0.0; use Zend_Loader_Autoloader instead', E_USER_NOTICE);
		require_once 'Zend/Loader/Autoloader.php';
		$autoloader = Zend_Loader_Autoloader::getInstance();
		$autoloader->setFallbackAutoloader(true);
		
		if ('Zend_Loader' != $class)
		{
			self::loadClass($class);
			$methods = get_class_methods($class);
			if (!in_array('autoload', (array) $methods))
			{
				require_once 'Zend/Exception.php';
				throw new Zend_Exception("The class \"$class\" does not have an autoload() method");
			}
			
			$callback = array(
				$class,
				'autoload'
			);
			
			if ($enabled)
			{
				$autoloader->pushAutoloader($callback);
			}
			else
			{
				$autoloader->removeAutoloader($callback);
			}
		}
	}
	
	protected static function _securityCheck($filename)
	{
		if (preg_match('/[^a-z0-9\\/\\\\_.:-]/i', $filename))
		{
			require_once 'Zend/Exception.php';
			throw new Zend_Exception('Security check: Illegal character in filename');
		}
	}
	
	protected static function _includeFile($filespec, $once = false)
	{
		if ($once)
		{
			return include_once $filespec;
		}
		else
		{
			return include $filespec;
		}
	}
	
	public static function standardiseFile($file)
	{
		$fileName = ltrim($file, '\\');
		$file = '';
		$namespace = '';
		if ($lastNsPos = strripos($fileName, '\\'))
		{
			$namespace = substr($fileName, 0, $lastNsPos);
			$fileName = substr($fileName, $lastNsPos + 1);
			$file = str_replace('\\', DIRECTORY_SEPARATOR, $namespace) . DIRECTORY_SEPARATOR;
		}
		$file .= str_replace('_', DIRECTORY_SEPARATOR, $fileName) . '.php';
		return $file;
	}
	
}

/* End of file Loader.php */
/* Location: ./cmv/libraries/Zend/Loader.php */