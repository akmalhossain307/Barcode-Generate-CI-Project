<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Zend_Barcode
{
	public static function factory($barcode, $renderer = 'image', $barcodeConfig = array(), $rendererConfig = array(), $automaticRenderError = true)
	{
		if ($barcode instanceof Zend_Config)
		{
			if (isset($barcode->rendererParams))
			{
				$rendererConfig = $barcode->rendererParams->toArray();
			}
			if (isset($barcode->renderer))
			{
				$renderer = (string) $barcode->renderer;
			}
			if (isset($barcode->barcodeParams))
			{
				$barcodeConfig = $barcode->barcodeParams->toArray();
			}
			if (isset($barcode->barcode))
			{
				$barcode = (string) $barcode->barcode;
			}
			else
			{
				$barcode = null;
			}
		}
		
		try
		{
			$barcode = self::makeBarcode($barcode, $barcodeConfig);
			$renderer = self::makeRenderer($renderer, $rendererConfig);
		}
		catch (Zend_Exception $e)
		{
			$renderable = ($e instanceof Zend_Barcode_Exception) ? $e->isRenderable() : false;
			if ($automaticRenderError && $renderable)
			{
				$barcode = self::makeBarcode('error', array(
					'text' => $e->getMessage()
				));
				$renderer = self::makeRenderer($renderer, array());
			}
			else
			{
				throw $e;
			}
		}
		
		$renderer->setAutomaticRenderError($automaticRenderError);
		return $renderer->setBarcode($barcode);
	}
	
	public static function makeBarcode($barcode, $barcodeConfig = array())
	{
		if ($barcode instanceof Zend_Barcode_Object_ObjectAbstract)
		{
			return $barcode;
		}
		
		if ($barcode instanceof Zend_Config)
		{
			if (isset($barcode->barcodeParams) && $barcode->barcodeParams instanceof Zend_Config)
			{
				$barcodeConfig = $barcode->barcodeParams->toArray();
			}
			if (isset($barcode->barcode))
			{
				$barcode = (string) $barcode->barcode;
			}
			else
			{
				$barcode = null;
			}
		}
		if ($barcodeConfig instanceof Zend_Config)
		{
			$barcodeConfig = $barcodeConfig->toArray();
		}
		
		if (!is_array($barcodeConfig))
		{
			require_once 'Zend/Barcode/Exception.php';
			throw new Zend_Barcode_Exception('Barcode parameters must be in an array or a Zend_Config object');
		}
		
		if (!is_string($barcode) || empty($barcode))
		{
			require_once 'Zend/Barcode/Exception.php';
			throw new Zend_Barcode_Exception('Barcode name must be specified in a string');
		}
		$barcodeNamespace = 'Zend_Barcode_Object';
		if (isset($barcodeConfig['barcodeNamespace']))
		{
			$barcodeNamespace = $barcodeConfig['barcodeNamespace'];
		}
		
		$barcodeName = strtolower($barcodeNamespace . '_' . $barcode);
		$barcodeName = str_replace(' ', '_', ucwords(str_replace('_', ' ', $barcodeName)));
		
		if (!class_exists($barcodeName))
		{
			require_once 'Zend/Loader.php';
			Zend_Loader::loadClass($barcodeName);
		}
		
		$bcAdapter = new $barcodeName($barcodeConfig);
		
		if (!$bcAdapter instanceof Zend_Barcode_Object_ObjectAbstract)
		{
			require_once 'Zend/Barcode/Exception.php';
			throw new Zend_Barcode_Exception("Barcode class '$barcodeName' does not extend Zend_Barcode_Object_ObjectAbstract");
		}
		return $bcAdapter;
	}
	
	public static function makeRenderer($renderer = 'image', $rendererConfig = array())
	{
		if ($renderer instanceof Zend_Barcode_Renderer_RendererAbstract)
		{
			return $renderer;
		}
		
		if ($renderer instanceof Zend_Config)
		{
			if (isset($renderer->rendererParams))
			{
				$rendererConfig = $renderer->rendererParams->toArray();
			}
			if (isset($renderer->renderer))
			{
				$renderer = (string) $renderer->renderer;
			}
		}
		if ($rendererConfig instanceof Zend_Config)
		{
			$rendererConfig = $rendererConfig->toArray();
		}
		
		if (!is_array($rendererConfig))
		{
			require_once 'Zend/Barcode/Exception.php';
			$e = new Zend_Barcode_Exception('Barcode parameters must be in an array or a Zend_Config object');
			$e->setIsRenderable(false);
			throw $e;
		}
		
		if (!is_string($renderer) || empty($renderer))
		{
			require_once 'Zend/Barcode/Exception.php';
			$e = new Zend_Barcode_Exception('Renderer name must be specified in a string');
			$e->setIsRenderable(false);
			throw $e;
		}
		
		$rendererNamespace = 'Zend_Barcode_Renderer';
		if (isset($rendererConfig['rendererNamespace']))
		{
			$rendererNamespace = $rendererConfig['rendererNamespace'];
		}
		
		$rendererName = strtolower($rendererNamespace . '_' . $renderer);
		$rendererName = str_replace(' ', '_', ucwords(str_replace('_', ' ', $rendererName)));
		
		if (!class_exists($rendererName))
		{
			require_once 'Zend/Loader.php';
			Zend_Loader::loadClass($rendererName);
		}
		
		$rdrAdapter = new $rendererName($rendererConfig);
		
		if (!$rdrAdapter instanceof Zend_Barcode_Renderer_RendererAbstract)
		{
			require_once 'Zend/Barcode/Exception.php';
			$e = new Zend_Barcode_Exception("Renderer class '$rendererName' does not extend Zend_Barcode_Renderer_RendererAbstract");
			$e->setIsRenderable(false);
			throw $e;
		}
		return $rdrAdapter;
	}
	
	public static function render($barcode, $renderer, $barcodeConfig = array(), $rendererConfig = array())
	{
		self::factory($barcode, $renderer, $barcodeConfig, $rendererConfig)->render();
	}
	
	public static function draw($barcode, $renderer, $barcodeConfig = array(), $rendererConfig = array())
	{
		return self::factory($barcode, $renderer, $barcodeConfig, $rendererConfig)->draw();
	}
	
	public static function setBarcodeFont($font)
	{
		require_once 'Zend/Barcode/Object/ObjectAbstract.php';
		Zend_Barcode_Object_ObjectAbstract::setBarcodeFont($font);
	}
	
}

/* End of file Barcode.php */
/* Location: ./cmv/libraries/Zend/Barcode.php */