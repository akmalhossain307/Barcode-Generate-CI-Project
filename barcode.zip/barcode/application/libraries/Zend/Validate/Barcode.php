<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

require_once 'Zend/Validate/Abstract.php';

require_once 'Zend/Loader.php';

class Zend_Validate_Barcode extends Zend_Validate_Abstract
{
	const INVALID = 'barcodeInvalid';
	const FAILED = 'barcodeFailed';
	const INVALID_CHARS = 'barcodeInvalidChars';
	const INVALID_LENGTH = 'barcodeInvalidLength';
	
	protected $_messageTemplates = array(self::FAILED => "'%value%' failed checksum validation", self::INVALID_CHARS => "'%value%' contains invalid characters", self::INVALID_LENGTH => "'%value%' should have a length of %length% characters", self::INVALID => "Invalid type given. String expected");
	
	protected $_messageVariables = array('length' => '_length');
	
	protected $_length;
	
	protected $_adapter;
	
	public function __construct($adapter)
	{
		if ($adapter instanceof Zend_Config)
		{
			$adapter = $adapter->toArray();
		}
		
		$options = null;
		$checksum = null;
		if (is_array($adapter))
		{
			if (array_key_exists('options', $adapter))
			{
				$options = $adapter['options'];
			}
			
			if (array_key_exists('checksum', $adapter))
			{
				$checksum = $adapter['checksum'];
			}
			
			if (array_key_exists('adapter', $adapter))
			{
				$adapter = $adapter['adapter'];
			}
			else
			{
				require_once 'Zend/Validate/Exception.php';
				throw new Zend_Validate_Exception("Missing option 'adapter'");
			}
		}
		
		$this->setAdapter($adapter, $options);
		if ($checksum !== null)
		{
			$this->setChecksum($checksum);
		}
	}
	
	public function getAdapter()
	{
		return $this->_adapter;
	}
	
	public function setAdapter($adapter, $options = null)
	{
		$adapter = ucfirst(strtolower($adapter));
		require_once 'Zend/Loader.php';
		if (Zend_Loader::isReadable('Zend/Validate/Barcode/' . $adapter . '.php'))
		{
			$adapter = 'Zend_Validate_Barcode_' . $adapter;
		}
		
		if (!class_exists($adapter))
		{
			Zend_Loader::loadClass($adapter);
		}
		
		$this->_adapter = new $adapter($options);
		if (!$this->_adapter instanceof Zend_Validate_Barcode_AdapterInterface)
		{
			require_once 'Zend/Validate/Exception.php';
			throw new Zend_Validate_Exception("Adapter " . $adapter . " does not implement Zend_Validate_Barcode_AdapterInterface");
		}
		
		return $this;
	}
	
	public function getChecksum()
	{
		return $this->getAdapter()->getCheck();
	}
	
	public function setChecksum($checksum)
	{
		$this->getAdapter()->setCheck($checksum);
		return $this;
	}
	
	public function isValid($value)
	{
		if (!is_string($value))
		{
			$this->_error(self::INVALID);
			return false;
		}
		
		$this->_setValue($value);
		$adapter = $this->getAdapter();
		$this->_length = $adapter->getLength();
		$result = $adapter->checkLength($value);
		if (!$result)
		{
			if (is_array($this->_length))
			{
				$temp = $this->_length;
				$this->_length = "";
				foreach ($temp as $length)
				{
					$this->_length .= "/";
					$this->_length .= $length;
				}
				
				$this->_length = substr($this->_length, 1);
			}
			
			$this->_error(self::INVALID_LENGTH);
			return false;
		}
		
		$result = $adapter->checkChars($value);
		if (!$result)
		{
			$this->_error(self::INVALID_CHARS);
			return false;
		}
		
		if ($this->getChecksum())
		{
			$result = $adapter->checksum($value);
			if (!$result)
			{
				$this->_error(self::FAILED);
				return false;
			}
		}
		
		return true;
	}
	
}

/* End of file Barcode.php */
/* Location: ./cmv/libraries/Zend/Validate/Barcode.php */