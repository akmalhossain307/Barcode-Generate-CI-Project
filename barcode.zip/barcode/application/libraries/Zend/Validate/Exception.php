<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

require_once 'Zend/Exception.php';

class Zend_Validate_Exception extends Zend_Exception
{
}

/* End of file Exception.php */
/* Location: ./cmv/libraries/Zend/Validate/Exception.php */