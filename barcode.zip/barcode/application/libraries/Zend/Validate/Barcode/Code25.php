<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

require_once 'Zend/Validate/Barcode/AdapterAbstract.php';

class Zend_Validate_Barcode_Code25 extends Zend_Validate_Barcode_AdapterAbstract
{
	protected $_length = -1;
	
	protected $_characters = '0123456789';
	
	protected $_checksum = '_code25';
	
	public function __construct()
	{
		$this->setCheck(false);
	}
}

/* End of file Code25.php */
/* Location: ./cmv/libraries/Zend/Validate/Barcode/Code25.php */