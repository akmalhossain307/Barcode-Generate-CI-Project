<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

require_once 'Zend/Validate/Barcode/AdapterInterface.php';

abstract class Zend_Validate_Barcode_AdapterAbstract implements Zend_Validate_Barcode_AdapterInterface
{
	protected $_length;
	
	protected $_characters;
	
	protected $_checksum;
	
	protected $_hasChecksum = true;
	
	public function checkLength($value)
	{
		if (!is_string($value))
		{
			return false;
		}
		
		$fixum = strlen($value);
		$found = false;
		$length = $this->getLength();
		if (is_array($length))
		{
			foreach ($length as $value)
			{
				if ($fixum == $value)
				{
					$found = true;
				}
				
				if ($value == -1)
				{
					$found = true;
				}
			}
		}
		elseif ($fixum == $length)
		{
			$found = true;
		}
		elseif ($length == -1)
		{
			$found = true;
		}
		elseif ($length == 'even')
		{
			$count = $fixum % 2;
			$found = ($count == 0) ? true : false;
		}
		elseif ($length == 'odd')
		{
			$count = $fixum % 2;
			$found = ($count == 1) ? true : false;
		}
		
		return $found;
	}
	
	public function checkChars($value)
	{
		if (!is_string($value))
		{
			return false;
		}
		
		$characters = $this->getCharacters();
		if ($characters == 128)
		{
			for ($x = 0; $x < 128; ++$x)
			{
				$value = str_replace(chr($x), '', $value);
			}
		}
		else
		{
			$chars = str_split($characters);
			foreach ($chars as $char)
			{
				$value = str_replace($char, '', $value);
			}
		}
		
		if (strlen($value) > 0)
		{
			return false;
		}
		
		return true;
	}
	
	public function checksum($value)
	{
		$checksum = $this->getChecksum();
		if (!empty($checksum))
		{
			if (method_exists($this, $checksum))
			{
				return call_user_func(array(
					$this,
					$checksum
				), $value);
			}
		}
		
		return false;
	}
	
	public function getLength()
	{
		return $this->_length;
	}
	
	public function getCharacters()
	{
		return $this->_characters;
	}
	
	public function getChecksum()
	{
		return $this->_checksum;
	}
	
	public function getCheck()
	{
		return $this->_hasChecksum;
	}
	
	public function setCheck($check)
	{
		$this->_hasChecksum = (boolean) $check;
		return $this;
	}
	
	protected function _gtin($value)
	{
		$barcode = substr($value, 0, -1);
		$sum = 0;
		$length = strlen($barcode) - 1;
		
		for ($i = 0; $i <= $length; $i++)
		{
			if (($i % 2) === 0)
			{
				$sum += $barcode[$length - $i] * 3;
			}
			else
			{
				$sum += $barcode[$length - $i];
			}
		}
		
		$calc = $sum % 10;
		$checksum = ($calc === 0) ? 0 : (10 - $calc);
		if ($value[$length + 1] != $checksum)
		{
			return false;
		}
		
		return true;
	}
	
	protected function _identcode($value)
	{
		$barcode = substr($value, 0, -1);
		$sum = 0;
		$length = strlen($value) - 2;
		
		for ($i = 0; $i <= $length; $i++)
		{
			if (($i % 2) === 0)
			{
				$sum += $barcode[$length - $i] * 4;
			}
			else
			{
				$sum += $barcode[$length - $i] * 9;
			}
		}
		
		$calc = $sum % 10;
		$checksum = ($calc === 0) ? 0 : (10 - $calc);
		if ($value[$length + 1] != $checksum)
		{
			return false;
		}
		
		return true;
	}
	
	protected function _code25($value)
	{
		$barcode = substr($value, 0, -1);
		$sum = 0;
		$length = strlen($barcode) - 1;
		
		for ($i = 0; $i <= $length; $i++)
		{
			if (($i % 2) === 0)
			{
				$sum += $barcode[$i] * 3;
			}
			else
			{
				$sum += $barcode[$i];
			}
		}
		
		$calc = $sum % 10;
		$checksum = ($calc === 0) ? 0 : (10 - $calc);
		if ($value[$length + 1] != $checksum)
		{
			return false;
		}
		
		return true;
	}
	
	protected function _postnet($value)
	{
		$checksum = substr($value, -1, 1);
		$values = str_split(substr($value, 0, -1));
		
		$check = 0;
		foreach ($values as $row)
		{
			$check += $row;
		}
		
		$check %= 10;
		$check = 10 - $check;
		if ($check == $checksum)
		{
			return true;
		}
		
		return false;
	}
	
}

/* End of file AdapterAbstract.php */
/* Location: ./cmv/libraries/Zend/Validate/Barcode/AdapterAbstract.php */