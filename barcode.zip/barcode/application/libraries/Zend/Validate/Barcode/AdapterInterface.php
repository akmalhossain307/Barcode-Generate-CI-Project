<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

interface Zend_Validate_Barcode_AdapterInterface
{
	public function checkLength($value);
	
	public function checkChars($value);
	
	public function checksum($value);
	
	public function getCheck();
	
	public function setCheck($check);
}

/* End of file AdapterInterface.php */
/* Location: ./cmv/libraries/Zend/Validate/Barcode/AdapterInterface.php */