<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

interface Zend_Validate_Interface
{
	public function isValid($value);
	
	public function getMessages();
}

/* End of file Interface.php */
/* Location: ./cmv/libraries/Zend/Validate/Interface.php */